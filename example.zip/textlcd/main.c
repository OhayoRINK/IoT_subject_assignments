
#include <wiringPi.h>
#include <stdio.h>
#include <unistd.h>
#include "lcd.h"

int main() {
    wiringPiSetupGpio();
    initLcd();

    printString("DUST: %");

    write_Command(0xC0);
    printString("GAS:  %");

    while (1) {
        delay(1000);
    }

    return 0;
}
