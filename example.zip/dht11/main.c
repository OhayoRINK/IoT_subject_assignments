#include <stdio.h>
#include <wiringPi.h>
#include <string.h>
#include <errno.h>		// strerror()
#include <stdlib.h>		// exit()

#include "dht11.h"

int gnTemp = 0;
int gnHumi = 0;

int main(void)
{
	if (wiringPiSetupGpio() == -1) {
		fprintf(stdout, "Unable to start wiringPi GPIO: %s\n", strerror(errno));
		return 1;
	}

	while (1)
	{
		delay(1000);
		readDht11(DHT_PIN);
		printf("Temperature	:	%d(C)\n", gnTemp);
		printf("Humidity	:	%d(%%)\n", gnHumi);
	}
	return 0;
}

