#include "dht11.h"

extern int gnTemp;
extern int gnHumi;

int readData(int nPin)
{
	// INIT BUFFERVAR TO RECEIVE DATA
	unsigned char cnt = 7;
	unsigned char idx = 0;
	int i;
	// EMPTY BUFFER
	for (i = 0; i < 5; i++)
		bits[i] = 0;

	// REQUEST SAMPLE
	pinMode(nPin, OUTPUT);
	digitalWrite(nPin, LOW);
	delay(20);
	digitalWrite(nPin, HIGH);
	delayMicroseconds(40);
	pinMode(nPin, INPUT);

	// GET ACKNOWLEDGE or TIMEOUT
	unsigned int loopCnt = TIMEOUT;
	while (digitalRead(nPin) == LOW)
	{
		if (loopCnt-- == 0) {
			return -2;
		}
	}
	loopCnt = TIMEOUT;
	while (digitalRead(nPin) == HIGH)
	{
		if (loopCnt-- == 0) {
			return -2;
		}
	}

	// READ THE OUTPUT - 40 BITS => 5 BYTES
	for (i = 0; i < 40; i++) {
		loopCnt = TIMEOUT;
		while (digitalRead(nPin) == LOW)
			if (loopCnt-- == 0)
				return -2;

		unsigned long t = micros();
		loopCnt = TIMEOUT;
		while (digitalRead(nPin) == HIGH)
			if (loopCnt-- == 0)
				return -2;

		if ((micros() - t) > 40) {
			bits[idx] |= (1 << cnt);
		}

		if (cnt == 0) { // next byte?
			cnt = 7;
			idx++;
		}
		else cnt--;
	}
	return 0;
}

//int readDht11(int nPin, int nMode)
int readDht11(int nPin)
{
	// READ VALUES
	int rv = readData(nPin);
	if (rv != 0) return rv;

	// CONVERT AND STORE
	gnHumi = bits[0];			// bit[1] == 0;
	gnTemp = bits[2];		// bits[3] == 0;

	return 0;

#if 0
	if (nMode == HUMI)
	{
		printf("humi = %d %% \r\n", gnHumi);
		return gnHumi;
	}
	printf("temp = %d C \r\n", gnTemp);
	return gnTemp;
#endif
}