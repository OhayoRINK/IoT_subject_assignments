#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <wiringPi.h>

#define DHT_PIN     26
#define TIMEOUT		10000

#define TEMP		0
#define HUMI		1

#if 0
typedef struct 
{
	int temperature;
	int humidity;
	int error;
}Stdht11Data;
#endif

unsigned char bits[5]; // buffer to receive data

int readData(int nPin);
int readDht11(int nPin);

