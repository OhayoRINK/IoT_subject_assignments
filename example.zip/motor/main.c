#include <stdio.h>
#include <wiringPi.h>
#include <string.h>
#include <errno.h>

#include <signal.h>
#include <stdlib.h>

#include "motor.h"

void sig_handler(int sig);

int main(void)
{
	signal(SIGINT, sig_handler);
	if(wiringPiSetupGpio() == -1) {
		fprintf(stdout, "Unable to start wiringPi GPIO: %s\n", strerror(errno));
		return 1;
	}

	initMotor();

	while(1)
	{
		controlMotor(ON, CLOCKWISE);
		delay(2000);
		controlMotor(OFF, CLOCKWISE);
		delay(4000);
		controlMotor(ON, COUNTERCLOCKWISE);
		delay(2000);
		controlMotor(OFF, COUNTERCLOCKWISE);
		delay(4000);
	}
	return 0;
}

void sig_handler(int sig)
{
	controlMotor(OFF, CLOCKWISE);
	exit(0);
}
