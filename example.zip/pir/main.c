#include <stdio.h>
#include <wiringPi.h>
#include <string.h>
#include <errno.h>		// strerror()
#include <stdlib.h>		// exit()

#include "pir.h"

int main(void)
{
	if (wiringPiSetupGpio() == -1) {
		fprintf(stdout, "Unable to start wiringPi GPIO: %s\n", strerror(errno));
		return 1;
	}

	initPir(PIR_PIN);

	while (1)
	{
		readPir(PIR_PIN);
	}
	return 0;
}
