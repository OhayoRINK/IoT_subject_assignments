#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>

/************************************************************************
Packet Format
0-1		:STX (0xFD, 0xFE)
2-5		:OBJECT ID
6-9		:Data 1
10-13	:Data 2
14		:ETX  (0x0FF)

Tatal packet size  is 15 byte.
*************************************************************************/
// packet index 
#define  INDEX_STX			0
#define  INDEX_OBJ_ID		(INDEX_STX + 2)
#define  INDEX_DATA1		(INDEX_OBJ_ID +4)
#define  INDEX_DATA2		(INDEX_DATA1+4)
#define  INDEX_ETX			(INDEX_DATA2 +4)

#define  PKT_LEN  	(INDEX_ETX +1)
#define  BUF_SIZE			256
#define  INIT_VAL_OF_MEM	0

#define  NUM_OF_ARGC	2		// INPUT Command and Port Number

#define  PROTOCOL_TYPE	0
#define  NUM_OF_QUEUE	5

#define  PKT_STX1	0xFD
#define  PKT_STX2	0xFE
#define  PKT_ETX	0xFF

#define  IP_MAX_LEN		16

#define  FLAG_RX		1
#define  FLAG_CLEAR		0

// socket status 
#define  SOCKET_DISCONNECT	0
#define  SOCKET_CONNECT		1

// server socket status
#define  SOCKET_DISCONNECTING	0
#define  SOCKET_CONNECTED		1

#define  STX_LEN			2
#define  DOMAIN_PWD_LEN		10
#define  MAX_DATA_NUM		2

#define  MAX_HANDLE_NUM		8
#define  MAX_SORT_NUM		4

// object_id list
#define	 LED         1
#define	 FAN         2
#define	 MOTOR       3
#define	 FND         4
#define	 TEXT_LCD    5
#define	 RGB_LED     6
#define	 STEP_MOTOR  7
#define	 BUZZER      8
#define	 BUTTON      9
#define	 CDS         10
#define	 PIR         11
#define	 PSD         12
#define	 PHOTO_INT   13
#define	 GAS         14
#define	 DUST        15
#define	 SOUND       16
#define	 UTRASONIC   17
#define	 TEMP_HUMI   18


// thingplus
#define TP_ID_LEN			20	
#define TP_TYPE_LEN			20	
#define TP_NAME_LEN			20	

typedef uint32_t handler_id;

typedef struct __attribute__((packed)) {
	unsigned char	stx[STX_LEN];
	unsigned int	object_id;
	int				data1;
	int				data2;
	unsigned char	etx;
} packetInfo;

// Socket
typedef struct {
	char			flag;
	char			ipAddr[IP_MAX_LEN];		// ip address
	int				connection;
	int				connect_sock;
	int				serv_sock;
	int				clnt_sock;
	int				servSocketConnection;	// server socket is connected & enable to accept client socket
	int				port;
	struct in_addr   sin_addr;
} socketInfo;

typedef struct {
	char			id[TP_ID_LEN];
	char			type[TP_TYPE_LEN];
	char			name[TP_NAME_LEN];
	int				value;
} tpPacketInfo;

typedef struct {
	char			flag;
//	socketInfo		serverSock;			// RaServer socket Info accepted Android app 
	packetInfo		contPacket;
//	pthread_t		pthread;
	tpPacketInfo	contTPPacket;
} ControlboardInfo;

typedef struct {
	char			flag;
	unsigned int	lastpacket;
	socketInfo		clientSock;			// android app
	packetInfo		raspPacket;
	packetInfo		clientPacket;
	socketInfo		serverSock;			// RaServer socket Info accepted Android app
	pthread_t		pthread;			// for server_thread
	int				fd;
} ServerInfo;

typedef struct __attribute__((packed)) {
	uint32_t		data;
}StEntity,*pStEntity;

typedef struct  __attribute__((packed)) {
	unsigned char	STX[2];
	uint32_t		obj_id;
	StEntity		stData[MAX_DATA_NUM];
	unsigned char	ETX;
}StProtoPkt, *pStProtoPkt;


void *server_thread(void *arg);
void *acceptClient_thread(void *arg);
void error_handling(char *message);

/*
  return value => handler_id
                  if return value < 0  , it is error
*/
handler_id createPktHandle(uint32_t obj_id);
							
/*
  return value => buffer pointer  ,
                  if return value  == -1 , error 
  resultLen(OUTPUT) => return buff length 				   
*/
unsigned char* makePkt(handler_id handleId, uint32_t* resultLen, uint32_t entity_value_1, uint32_t entity_value_2);



#endif	// __PROTOCOL_H__
