#include "pir.h"

int gnPirState = LOW;             // we start, assuming no motion detected

void initPir(int nPin)      // choose the input pin (for PIR sensor)
{
	pinMode(nPin, INPUT);     // declare sensor as input
}

int readPir(int nPin)
{
	int nPirVal = 0;                  // variable for reading the pin status
	nPirVal = digitalRead(nPin);  // read input value
	if (nPirVal == HIGH) {            // check if the input is HIGH
		if (gnPirState == LOW) {
			// we have just turned on
			printf("Motion detected!\n");
			// We only want to print on the output change, not state
			gnPirState = HIGH;
		}
	}
	else {
		if (gnPirState == HIGH) {
			// we have just turned off
			printf("Motion ended!\n");
			// We only want to print on the output change, not state
			gnPirState = LOW;
		}
	}
	return nPirVal;
}