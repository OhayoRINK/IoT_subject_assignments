#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <pthread.h>
#include <sys/socket.h>
#include <unistd.h>				// sleep()

#include "protocol.h"
#include "pir.h"

#define DEBUG_MODE
//#define DEBUG_MODE_PACKET_CONT
//#define DEBUG_MODE_PACKET_SERVER


char gcRecvBuf[BUF_SIZE];		// incoming serial byte
unsigned char gucRecvCnt = 0;

char gcSendBuf[BUF_SIZE];		// sending serial byte
unsigned char gucSendCnt = 0;

void error_handling(char *message);

void *acceptClient_thread(void *arg);
void *server_thread(void *arg);

int gnPir = 0;


/*******************************************************************************/
//  DEVICE  ACCESS FUNCTION
/*******************************************************************************/

// UART Communication buffer
void ClearBuffer(void)
{
	int i;
	for(i = 0 ; i<BUF_SIZE ; i++) {
		gcRecvBuf[i] = 0;		// '\0'
	}
}

void SendSensorData(handler_id handleId, int Data1, int Data2)
{
//	printf("send sensor data\n");
	uint32_t len;
	uint8_t* buff;
	buff = makePkt(handleId, &len, Data1, Data2);		// make packet
	if (buff == 0)
	{
		//		printf("SendSensor Data -- makePkt error.\n");
		return;
	}
#ifdef DEBUG_MODE
	printf("TX:\r\n");
	//	printf("Tx Serial(%d):",len);
	for (int i = 0; i < len; i++) {
		printf("[%02X]", buff[i]);
		gcSendBuf[i] = buff[i];
	}
	printf("\n");
#endif
}


// init Variables
void initVariableServer(ServerInfo* stData)
{
	memset(stData, 0, sizeof(ServerInfo));
}


int main(int argc, char *argv[])
{
	pthread_t pthreadRaspAcceptAndroidClient;	// acceptClient_thread , control Client acception mange

	ServerInfo rasInfo;					// Raspberry Pi Server Information
	ServerInfo *ptr_rasInfo;
	ptr_rasInfo = &rasInfo;


	packetInfo *ptr_contPacket;

	// init variables
	initVariableServer(ptr_rasInfo);

// Ra Server
	// check input port info
	if(argc != NUM_OF_ARGC) {
		printf("Usage: %s <port> \n", argv[0]);
		printf("      ex)./ras_server 50002 \n");
		exit(1);
	}

	// argv[1] => client port number
	ptr_rasInfo->clientSock.port = atoi(argv[1]);
//	printf("port : %d\n", ptr_rasInfo->clientSock.port);
	
	ptr_rasInfo->clientSock.connection = SOCKET_DISCONNECT;

	int serv_sock, clnt_sock;
	
	struct sockaddr_in serv_adr;
	
	int option;

	// get server socket
	serv_sock =  socket(PF_INET, SOCK_STREAM, PROTOCOL_TYPE);
	if (serv_sock == -1)
		error_handling("socket() error");
	// inform serv_sock to client
	ptr_rasInfo->serverSock.serv_sock = serv_sock;

	//soket option - reuse binded address
	option = 1;
	setsockopt(serv_sock, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));
//	fcntl(serv_sock, F_SETFL, option | O_NONBLOCK);
	
	memset(&serv_adr, INIT_VAL_OF_MEM, sizeof(serv_adr));

	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);	// get ip address
	serv_adr.sin_port = htons(atoi(argv[1]));		// get port num
//	printf("port : %d\n", htons(atoi(argv[1])));

	// bind .  for the connection request of control board
	if (bind(serv_sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1) {
		error_handling("bind() error");
		close(serv_sock);
	}
	
	// listen
	if (listen(serv_sock, NUM_OF_QUEUE) == -1) {
		error_handling("listen() error");
		close(serv_sock);
	}
	
	if (wiringPiSetup () == -1) {
		fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
		return 1 ;
	}	
	if (wiringPiSetupGpio() == -1) {
		fprintf(stdout, "Not start wiringPi: %s\n", strerror(errno));
		return 1;
	}

	ClearBuffer();

	initPir(PIR_PIN);


	printf("Raspberry Pi - Arduino Serial Communication\r\n");
	while(1)
	{
		if ( ptr_rasInfo->serverSock.connection == SOCKET_DISCONNECT) 
		{
			if ( ptr_rasInfo->clientSock.servSocketConnection == SOCKET_DISCONNECTING)
			{
				printf("enter wait accept\n");
				// accept android client
				if(pthread_create(&pthreadRaspAcceptAndroidClient, NULL, acceptClient_thread, (void*)&rasInfo) == -1)	{
					error_handling("pthread_create() error");
				}
				else {
					printf("acceptClient thread start\n");
					ptr_rasInfo->serverSock.connection = SOCKET_CONNECT;
				}
			}
		}

		handler_id  handleIdSensor = -1;		// Sensor


#if 1
		while (1)		// arduino => raspberry Rx
		{
			delay(1);
			if (ptr_rasInfo->clientSock.servSocketConnection == SOCKET_CONNECT)
			{
				delay(1000);
				gnPir = readPir(PIR_PIN);
				handleIdSensor = createPktHandle((uint32_t)PIR);
				SendSensorData(handleIdSensor, gnPir, 0);


				ptr_contPacket = (packetInfo*)gcSendBuf;


#if 1	// wirte data : Control BD -> Android App
				ptr_rasInfo->raspPacket = *ptr_contPacket;		// for send android

				if (ptr_rasInfo->clientSock.servSocketConnection != SOCKET_DISCONNECTING)
				{
					if ((ptr_rasInfo->flag = FLAG_RX))
					{
						ptr_rasInfo->flag = FLAG_CLEAR;

						clnt_sock = 0;
						clnt_sock = ptr_rasInfo->serverSock.clnt_sock;
						//				printf("Android clnt_sock : %d\n", clnt_sock);
						//				usleep(1000*1000);
						int writeBufSize;
						if (clnt_sock != 0)
						{
							writeBufSize = write(clnt_sock, (struct packetInfo*)&(ptr_rasInfo->raspPacket), sizeof(ptr_rasInfo->raspPacket));
							printf("==== write : rasp server-> android client \n");
							if (writeBufSize < 1) {
								printf("write error : rasp server-> android client \n");
							}
						}
						else {
							printf("Android client socket don't open. \n");
						}
					}
				}
			}
#endif
		}	// while()
#endif
	}
	return 0;
}

// pthreadRaspAcceptAndroidClient. Android Client acception manage
void *acceptClient_thread(void *arg)
{
	pthread_detach(pthread_self());

	ServerInfo *rasInfo;
	rasInfo = ((ServerInfo *)arg);

	int serv_sock, clnt_sock;
	
//	struct sockaddr_in serv_adr;
	struct sockaddr_in clnt_adr;
	socklen_t clnt_adr_sz;
	
	serv_sock = rasInfo->serverSock.serv_sock;
//	printf("serv_sock : %d\n", rasInfo->serverSock.serv_sock);
	
	printf("[CET] ");
	printf("ready to accept client...\n");

	clnt_adr_sz = sizeof(clnt_adr);

	clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &clnt_adr_sz);
	printf("clnt_sock : %d\n", clnt_sock);		// Android socket
	rasInfo->serverSock.clnt_sock = clnt_sock;

	if(clnt_sock == -1)	{
		error_handling("accept() error");
		rasInfo->serverSock.connection = SOCKET_DISCONNECT;
//		close(serv_sock);
	}
	else {
		rasInfo->clientSock.servSocketConnection = SOCKET_CONNECTED;
		printf("accept() success \n");
	}

	printf("Connected Client IP : %s\n", inet_ntoa(clnt_adr.sin_addr));
	printf("Client Port Num : %d\n\n", ntohs(clnt_adr.sin_port));

	if(pthread_create(&rasInfo->pthread, NULL , server_thread , (void*)rasInfo) == -1) {
		error_handling("acceptClient_thread -- pthread_create() error");
		rasInfo->serverSock.clnt_sock = 0;
//		rasInfo->serverSock.connection = SOCKET_DISCONNECT;
		rasInfo->clientSock.servSocketConnection = SOCKET_DISCONNECT;
		close(clnt_sock);
//		close(serv_sock);
	}
	else {
		rasInfo->serverSock.connection = SOCKET_CONNECT;
		printf("server thread start\n");
	}
	printf("thread acceptClient_thread stoped.....\n");
	return 0;
}

// read data : Android App -> rasp Server
void *server_thread(void *arg)
{
	pthread_detach(pthread_self());

	ServerInfo *rasInfo;
	rasInfo = ((ServerInfo *)arg);

//	packetInfo clientPacket = rasInfo->clientPacket;

	int clnt_sock = rasInfo->serverSock.clnt_sock;
//	printf("clnt_sock : %d \n", clnt_sock);

	char* rcv_buf;
	int readBufSize;
	int i;
	// monitor pthread
//	int status;

	unsigned char sendingErr = 0;

	printf(" server_thread main loop\n");
	while(1)
	{
		
		readBufSize = read(clnt_sock, (char*)&rasInfo->clientPacket, sizeof(packetInfo));
		
		rcv_buf = (char *)&rasInfo->clientPacket;

		if(readBufSize > 0)	
		{
			printf("==== read from Android. rx len:%d\n", readBufSize);

			// ��Ŷ ���� ����Ͽ� ���� packetlen ���� ��
			
#ifdef DEBUG_MODE
			printf("RX from Android:\r\n");
			int k;
			for( k=0; k<sizeof(packetInfo); k++ )	{
				printf("[%02x]", rcv_buf[k]);
			}
			printf("\n");
#endif

			if(rcv_buf[INDEX_STX] == PKT_STX1 && rcv_buf[INDEX_STX+1] == PKT_STX2) 
			{
	#ifdef DEBUG_MODE_PACKET_CONT
				printf(" stx : %x %x\n", rcv_buf[INDEX_STX], rcv_buf[INDEX_STX+1]);
	#endif
				if(rcv_buf[INDEX_ETX] == PKT_ETX) 
				{
					rasInfo->flag = FLAG_RX;
					
//					rasInfo->contTPPacket.value = rasInfo->clientPacket.data1;
//					printf(" value : %08x\n", rasInfo->contTPPacket.value);
					
	#ifdef DEBUG_MODE_PACKET_CONT
					printf(" object_id : %08x\n", rasInfo->clientPacket.object_id);
					printf(" data1 : %08x\n", rasInfo->clientPacket.data1);
					printf(" data2 : %08x\n", rasInfo->clientPacket.data2);
	#endif
					sendingErr = 0;
				}
				else {
					printf("etx is wrong.\n");
					sendingErr = 1;
				}
			}
			else {								//when app is stopped?
				printf("stx is wrong.\n");
				sendingErr = 1;
			}
			
			if(sendingErr == 1)	{
			}
			else {
	#ifdef DEBUG_MODE
				printf("Android=>raspberry Rx OK\n");
	#endif
				for(i = 0; i < PKT_LEN ; i++)
				{
					serialPutchar (rasInfo->fd, rcv_buf[i]) ;
				}
	#ifdef DEBUG_MODE
				printf("\nTx Serial(%d): \n",PKT_LEN);
				for( i= 0; i < PKT_LEN ; i++)
				{
					printf("[%02X]", rcv_buf[i]);
				}
				printf("\n");
	#endif
			}
		}
		else if (readBufSize == 0) {			// when app is stopped,
			printf("readBufSize : 0\n");
			break;			
		}
		else {					// readBufSize < 0
			printf("Android read() error , readBufSize:%d\n", readBufSize);
			break;
		}
	}
	printf("close clnt_sock.\n");
	close(clnt_sock);
	rasInfo->serverSock.clnt_sock =0;
	rasInfo->clientSock.servSocketConnection = SOCKET_DISCONNECT;
	rasInfo->serverSock.connection = SOCKET_DISCONNECT;

	printf("thread server_thread stoped.....\n");
	return 0;
}


void error_handling(char *message)
{
	fputs(message, stderr);
	fputc('\n', stderr);
}
