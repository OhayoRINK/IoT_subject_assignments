#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>

#define PIR_PIN   27

void initPir(int nPin);
int readPir(int nPin);
