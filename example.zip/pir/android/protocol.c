#include "protocol.h"
#include <string.h>
#include <stdint.h>

volatile StProtoPkt stPktArr[MAX_HANDLE_NUM];
volatile uint32_t  currentHandlesize = 0; 

//handler_id createPktHandle(uint32_t obj_id, unsigned char data1, unsigned char data2)
handler_id createPktHandle(uint32_t obj_id)
{
//	printf("currentHandlesize = %d\n", currentHandlesize);		//8
	if ( currentHandlesize >= MAX_HANDLE_NUM)
		return -1;
	
	uint32_t temId = 	currentHandlesize;
	
	stPktArr[temId].STX[0] = 0xfd;
	stPktArr[temId].STX[1] = 0xfe;
	
	stPktArr[temId].obj_id = obj_id;

	#if 1 // for test --------------------------------------------------------------------
//	stPktArr[temId].based_id = 0x00345678;
//	stPktArr[temId].based_id = 0x00000000;
	#endif
	
//	stPktArr[temId].stData[0].data = data1;
//	stPktArr[temId].stData[1].data = data2;

	stPktArr[temId].ETX = 0xff;
	currentHandlesize++;
	if (currentHandlesize >= 8) {
		currentHandlesize = 0;
	}

	return temId;	
}

unsigned char* makePkt(handler_id handleId, uint32_t* resultLen, uint32_t data1, uint32_t data2)
{
//	printf("handleId = %d\n", handleId);
//	printf("currentHandlesize = %d\n", currentHandlesize);
//	printf("handleId >= currentHandlesize = %d\n", (handleId >= currentHandlesize));
//	if (handleId >= currentHandlesize )
//	{
//		printf("SendSensor Data -- currentHandlesize error.\n");
//		return NULL;
//	}
	
	stPktArr[handleId].stData[0].data = data1;
	stPktArr[handleId].stData[1].data = data2;
	
	*resultLen = sizeof(StProtoPkt);
	return (unsigned char*)(stPktArr+handleId);
}

uint32_t pktParcingActuatorControl(unsigned char* buff, uint32_t* obj_id, int32_t* entCtlValue1, int32_t* entCtlValue2  )
{
	if ( (buff[INDEX_STX] != 0xFD) || (buff[INDEX_STX+1] != 0xFE) )
	{
		return -1;		
	}
	
	if (buff[INDEX_ETX] != 0xFF)
	{
		return -1;
	}
	
	*obj_id = *(unsigned int*)(buff+INDEX_OBJ_ID);
	*entCtlValue1 = *(int32_t*)(buff+INDEX_DATA1);
	*entCtlValue2 = *(int32_t*)(buff+INDEX_DATA2);
	
	
	return 0;
}

unsigned int getObj_idFromHandler(handler_id handleId)
{
	if (handleId >= currentHandlesize )
	{
		return -1;
	}	
	return stPktArr[handleId].obj_id;
}