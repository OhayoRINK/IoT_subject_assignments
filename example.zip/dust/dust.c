#include "dust.h"
#include "adc.h"

float Vo_Val = 0;
float Voltage = 0;
float dustDensity = 0;

int samplingTime = 280;   // 0.28ms
int delayTime = 40;       // 0.32 - 0.28 = 0.04ms
int offTime = 9680;       // 10 - 0.32 = 9.68ms

void initDustSensor(int nLedPin)
{
	pinMode(nLedPin, OUTPUT);
}

float readDustSensor(int analogPin, int ledPin)
{
//	int inputVal = 0;
	digitalWrite(ledPin, LOW);
	delayMicroseconds(samplingTime);
	
	Vo_Val = readAdc(analogPin);
	printf("Vo_Val : %f, ", Vo_Val);

	delayMicroseconds(delayTime);
	digitalWrite(ledPin, HIGH);
	delayMicroseconds(offTime);

	Voltage = (Vo_Val * 3.3 / 1024.0) / 3.0;
	dustDensity = (0.172*(Voltage) - 0.0999) * 1000;

	printf("Voltage : %f, ", Voltage);
	printf(" Value : %f(ug/m3)\n", dustDensity);

	return dustDensity;
}