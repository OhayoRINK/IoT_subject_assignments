#include <stdio.h>
#include <wiringPi.h>
#include <string.h>
#include <errno.h>		// strerror()
#include <stdlib.h>		// exit()

#include "adc.h"
#include "dust.h"


int main(void)
{

	float gfDust = 0;

	if (wiringPiSetupGpio() == -1) {
		fprintf(stdout, "Unable to start wiringPi GPIO: %s\n", strerror(errno));
		return 1;
	}
	if (wiringPiSPISetup(SPI_CHANNEL, SPI_SPEED) == -1) {
		fprintf(stdout, "wiringPiSPISetup Failed: %s\n", strerror(errno));
		return 1;
	}

	initDustSensor(DUST_LED_PIN);
	pinMode(CS_MCP3208, OUTPUT);

	while (1)
	{
		delay(7000);
		gfDust = readDustSensor(DUST_PIN, DUST_LED_PIN);
		printf("Dust : %f\r\n", gfDust);
	}
	return 0;
}
